<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    Mews\Captcha\CaptchaServiceProvider::class,
];
