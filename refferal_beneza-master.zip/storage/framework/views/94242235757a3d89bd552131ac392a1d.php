<?php $__env->startSection('title'); ?>
Add Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
.errors{
color:red;
}
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content mt-3">
    <div class="container-fluid">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title float-left mt-1">Add Cateogry</h3>
            </div>
            <div class="card-body">
                <form id="category_form" action="<?php echo e(url('admin/category')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Category</label>
                                <input type="text" name="name" id="name" class="form-control"
                                    placeholder="Enter User" value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger font-weight-bold error-name"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <!-- <span class="text-danger fw-bold" style="font-weight: bold;" id='error_name'></span> -->
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit"
                                class="btn btn-primary btn-sm float-right mt-2">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- jquery-validation -->
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/additional-methods.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $('#category_form').validate({
        errorClass: 'errors',
        ignore: [],
        rules: {
            name: {
                required: true,
            }
        },
        message: {
            name: {
                required: "Please enter your Category name",
            }
        },
        // errorElement: 'p',
        // errorPlacement: function(error, element) {
        //     error.addClass('invalid-feedback display-4 font-weight-bold');
        //     element.closest('.form-group').append(error);
        // },
        highlight: function(element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        },
        submitHandler: function() {
            $('#submit_form')[0].submit();
        }
    })
    $(document).ready(function() {
        // Remove error and invalid class when user types in email field
        $('#name').on('input', function() {
            $('.error-name').remove();
        });

      
        // Handle other input fields similarly if needed
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\admin\pages\AddCategory.blade.php ENDPATH**/ ?>