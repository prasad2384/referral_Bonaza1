<!DOCTYPE html>
<html>

    <head>
        <?php echo $__env->make('admin.partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <style>
            <?php echo $__env->yieldContent('style'); ?>
        </style>
    </head>

    <body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">

            <?php echo $__env->make('admin.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->yieldContent('scripts'); ?>
            </div>
            <!-- /.content-wrapper -->
            <?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Control sidebar content goes here -->
            </aside>
            <!-- /.control-sidebar -->
        </div>
        <!-- ./wrapper -->

        <!-- jQuery -->
        <?php echo $__env->make('admin.partial.footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $.widget.bridge('uibutton', $.ui.button)
        </script>

    </body>

</html>
<?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\admin\layout.blade.php ENDPATH**/ ?>