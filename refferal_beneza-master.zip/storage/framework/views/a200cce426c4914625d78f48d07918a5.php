<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<!-- ======================= Edit Profile START -->
<section class="position-relative overflow-hidden pb-0 pt-xl-9 profile-section">
    <div class="container pt-4 pt-sm-5">
        <div class="row pb-5 g-xl-5">
            <!-- Hero Image START -->
            <div class="col-sm-12  col-lg-3 my-auto profile-img">
                <!-- Hero image -->
                <?php if($data_user->logo == ''): ?>
                <img src="<?php echo e(asset('images/default_user_logo.png')); ?>" style="height:210px; width:210px" alt="profile-img" class="rounded rounded-circle">
                <?php else: ?>
                <img src="<?php echo e(asset('images/' . $data_user->logo)); ?>">
                <?php endif; ?>
            </div>
            <!-- Hero Image END -->
            <div class="col-sm-12 col-lg-9 profile-details">
                <div class="d-md-flex d-block profile-info">
                    <div class="profile-data">
                        <h2>Hi <?php echo e($data_user->firstname); ?> <?php echo e($data_user->lastname); ?></h2>
                        <h4 class="d-flex">
                            <span class="user-select-none">localhost:8000/user_profile/<?php echo e($data_user->id); ?> </span><img src="<?php echo e(asset('images/img-9.png')); ?>" class="rounded" id="copyImage" alt="box-icon">
                            <span class="notification rounded-pill fs-6 p-2 d-none bg-black text-white" id="notification"> copied!</span>
                        </h4>

                    </div>

                    <div class="profile-btn">
                        <!-- <a class="edit-btn mx-3" href="<?php echo e(url('user/user_message/' . $data_user->id)); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-square"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                            Message
                        </a> -->
                        <a class="edit-btn" href="<?php echo e(url('user/edit_profile/' . $data_user->id)); ?>"><img src="<?php echo e(asset('images/img13.png')); ?>" class="rounded" alt="msg-icon">Edit
                            profile
                        </a>
                    </div>
                </div>
                <p>
                    <?php for($i=0;$i< 5; $i++): ?>
                        <?php if($i < $average_rating): ?>
                        <span class="star">&#9733;</span>
                        <?php else: ?>
                        <span class="empty-star">&#9734;</span>
                        <?php endif; ?>
                        <?php endfor; ?>
                        <!-- <img src="<?php echo e(asset('images/img-10.png')); ?>" alt="rating" /> --></p>
                <div class="profile-list">
                    <p class="pl-1">Member Since <?php echo e($data_user->created_at->format('Y')); ?> |
                        <span><?php echo e($referral_links_count); ?> </span>Referral Codes Created |
                        <span><?php echo e($total_clicks); ?>

                        </span>Clicks Received |<span> 50 </span> Bonus Received
                    </p>
                    <p class="pl-1 pl-data"><?php echo e($data_user->about); ?></p>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- ======================= Edit Profile END -->
<!-- ======================= Edit Profile body START -->
<section class="position-relative overflow-hidden pb-0 mt-5 pt-xl-9 referal-sec">
    <div class="container pt-4 pt-sm-5">
        <div class="row pb-5 mt-5 mb-5 mx-1">
            <div class="d-flex justify-content-between align-items-start">
                <h4 class="heading-underline mb-5 text-uppercase"> <?php echo e($data_user->firstname); ?>’S REFERRALS</h4>
                <!-- <a class="btn btn-primary" href="<?php echo e(route('share.referral.link')); ?>">Add Refferal Link</a> -->
            </div>
            <div class="editProfile-table mb-5 table-responsive">
                <table class="table your-clicks">
                    <thead>
                        <tr>
                            <th scope="col">WEBSITE</th>
                            <th scope="col">OFFER AMOUNT</th>
                            <th scope="col">REFFERED ON</th>
                            <th scope="col">TRANSATION RATING</th>
                            <th scope="col">TRANASCTION COMMENTS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $referral_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><img src="<?php echo e(asset('images/' . $referral_link->logo)); ?>" alt="name">
                            </td>
                            <td>$<?php echo e($referral_link->expected_payout_by_referar); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($referral_link->created_at)->format('d-m-Y')); ?></td>

                            <td>
                                <?php
                                $totalRating = 0;
                                $ratingCount = 0;
                                ?>
                                <?php $__currentLoopData = $all_ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($referral_link->id == $rating->referral_link_id): ?>
                                <?php
                                $totalRating += $rating->rating; // Assuming the rating column is 'rating'
                                $ratingCount++;
                                ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $averageRating = $ratingCount > 0 ? ceil($totalRating / $ratingCount) : 0;
                                $fullStars = $averageRating; // Number of full stars to display
                                $emptyStars = 5 - $fullStars; // Number of empty stars to display
                                ?>
                                <?php if($ratingCount > 0): ?>
                                <?php for($i = 0; $i < $fullStars; $i++): ?>
                                    <span class="star">&#9733;</span> <!-- Full Star -->
                                    <?php endfor; ?>

                                    <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                        <span class="empty-star">&#9734;</span> <!-- Empty Star -->
                                        <?php endfor; ?>
                                        <?php else: ?>
                                        <?php for($i=1;$i<=5;$i++): ?>
                                            <span class="empty-star">&#9734;</span>
                                            <?php endfor; ?>
                                            <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $displayedReferrerIds = [];
                                $messageDisplayed = false;
                                ?>

                                <?php $__currentLoopData = $user_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($review->user_id == $data_user->id && $review->referral_link_id == $referral_link->id): ?>
                                <?php if(!in_array($review->referrer_id, $displayedReferrerIds)): ?>
                                <?php echo e($review->message); ?>

                                <?php
                                $displayedReferrerIds[] = $review->referrer_id;
                                $messageDisplayed = true;
                                ?>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if(!$messageDisplayed): ?>
                                Lorem ipsum dolor sit amet consectetur.
                                <?php endif; ?>
                                <!-- Lorem ipsum dolor sit amet consectetur. -->
                            </td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="12" class="text-center">Referral Link Not Found</td>
                        </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- ======================= Edit Profile body START -->

<!-- ======================= Edit Profile body END -->

<section class="position-relative overflow-hidden pb-0 pt-xl-9 comment-section">
    <div class="container pt-4 pt-sm-5">
        <div class="row pb-5 mt-5 mb-5">
            <h4 class="heading-underline">RATINGS & COMMENTS</h4>
            <div class="row">
                <div class="col-lg-4 pe-5">
                    <div class="d-flex align-items-center mb-2">
                        <div class="d-flex rating-img">
                            <?php for($i = 0; $i < 5; $i++): ?>
                                <?php if($i < $average_rating): ?>
                                <span class="star">&#9733;</span> <!-- Full Star -->
                                <?php else: ?>
                                <span class="empty-star">&#9734;</span> <!-- Empty Star -->
                                <?php endif; ?>
                                <?php endfor; ?>
                        </div>
                        <h5 class="mb-0 ms-2"><?php echo e($total_ratings); ?> Average Ratings</h5>
                    </div>


                    <!-- this is rating code  -->

                    <div class="row bg-white pt-2">
                        <div class="col-md-12 d-flex align-items-center  mb-2">
                            <p class=" mb-0 ms-1 me-2 text-primary" style="font-size: 15px;">5 star</p>

                            <div class="progress mx-2" style="height: 25px; width:60%">
                                <div class="progress-bar bg-warning" role="progressbar" style="width:<?php echo e($percentages['5_star']); ?>%" aria-valuenow="<?php echo e($percentages['5_star']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="mx-2 text-primary"><?php echo e(round($percentages['5_star'], 2)); ?>%</span>
                        </div>
                    </div>
                    <div class="row bg-white">
                        <div class="col-md-12 d-flex align-items-center mb-2">
                            <p class="text-primary mb-0 ms-1 me-2" style="font-size: 15px;">4 star</p>
                            <div class="progress  mx-2" style="height: 25px; width:60%;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width:<?php echo e($percentages['4_star']); ?>%" aria-valuenow="<?php echo e($percentages['4_star']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="mx-2 text-primary"><?php echo e(round($percentages['4_star'], 2)); ?>%</span>
                        </div>
                    </div>
                    <div class="row bg-white">
                        <div class="col-md-12 d-flex align-items-center mb-2">
                            <p class="text-primary mb-0 ms-1 me-2" style="font-size: 15px;">3 star</p>
                            <div class="progress  mx-2" style="height: 25px; width:60%">
                                <div class="progress-bar bg-warning" role="progressbar" style="width:<?php echo e($percentages['3_star']); ?>%" aria-valuenow="<?php echo e($percentages['3_star']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="mx-2 text-primary"><?php echo e(round($percentages['3_star'], 2)); ?>%</span>
                        </div>
                    </div>
                    <div class="row bg-white">
                        <div class="col-md-12 d-flex align-items-center mb-2">
                            <p class="text-primary mb-0 ms-1 me-2" style="font-size: 15px;">2 star</p>
                            <div class="progress  mx-2" style="height: 25px; width:60%">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($percentages['2_star']); ?>%" aria-valuenow="<?php echo e($percentages['2_star']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="mx-2 text-primary" style="font-size: 15px;"><?php echo e(round($percentages['2_star'], 2)); ?>%</span>
                        </div>
                    </div>
                    <div class="row bg-white">
                        <div class="col-md-12 d-flex align-items-center mb-2">
                            <p class="text-primary mb-0 ms-1 me-2" style="font-size: 15px;">1 star</p>
                            <div class="progress  mx-2" style="height: 25px; width:60%">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($percentages['1_star']); ?>%" aria-valuenow="<?php echo e($percentages['1_star']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="mx-2 text-primary fs-6"><?php echo e(round($percentages['1_star'], 2)); ?>%</span>
                        </div>
                    </div>


                    <!-- this is the end of rating code  -->
                    <!-- <img src="<?php echo e(asset('images/img14.png')); ?>" alt="referral-img"> -->
                </div>
                <div class="col-lg-8">
                    <div class="rating-content">
                        <h5>User Reviews</h5>
                        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                            printer
                            took a galley of type and scrambled it to make a type specimen book.</p>
                        <div class="d-flex pb-5 rating-labels">
                            <span><i class="fa-solid fa-circle-check"></i>Ease Of Use</span>
                            <span><i class="fa-solid fa-circle-check"></i>Good Value</span>
                            <span><i class="fa-solid fa-circle-check"></i>Would Recommend</span>
                        </div>
                    </div>
                    <?php $__currentLoopData = $user_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pt-5 pb-5 rating-content">
                        <h5>Latest Ratings</h5>
                        <div class="pt-4 d-flex">
                            <div class="row  g-xl-5">
                                <div class=" col-lg-3 pr-0 rating-profile-img">
                                    <?php $__currentLoopData = $user_referee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($referee->id == $review->referee_id): ?>
                                    <?php if($referee->logo == ''): ?>

                                    <img src="<?php echo e(asset('images/default_user_logo.png')); ?>" alt="profile-img">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('images/'.$referee->logo)); ?>" alt="profile-img">

                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-lg-9 px-2 rating-profile-details">
                                    <div class="d-flex rating-profile-info">
                                        <div class="rating-profile-data">
                                            <h5 class="m-0">
                                                <?php $__currentLoopData = $user_referee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($referee->id == $review->referee_id): ?>
                                                <?php echo e($referee->firstname); ?> <?php echo e($referee->lastname); ?>

                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </h5>
                                        </div>
                                    </div>
                                    <p class="" style="margin-bottom: 10px;">
                                        <?php for($i=1;$i<=5;$i++): ?>
                                        <span class="empty-star">&#9734;</span>
                                        <?php endfor; ?>
                                        <!-- <img src="<?php echo e(asset('images/img-10.png')); ?>" alt="rating"> -->
                                    </p>
                                    <p class="mb-3 review-label">Reviewed on <?php echo e($review->created_at->format('d F Y')); ?></p>
                                </div>

                            </div>
                        </div>
                        <p><?php echo e($review->message); ?></p>
                        <span>Verified User : Yes</span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-2">

                        <?php echo e($user_review->links()); ?>

                    </div>
                    <!-- <div class="pt-5 pb-5 rating-content">
                        <div class="d-flex">
                            <div class="row  g-xl-5">
                                <div class=" col-lg-3 pr-0 rating-profile-img">
                                    <img src="<?php echo e(asset('images/img15.png')); ?>" alt="profile-img">
                                </div>
                                <div class="col-lg-9 px-2 rating-profile-details">
                                    <div class="d-flex rating-profile-info">
                                        <div class="rating-profile-data">
                                            <h5>Andrew Marsh</h5>
                                        </div>
                                    </div>
                                    <p class="mb-0"><img src="<?php echo e(asset('images/img-10.png')); ?>" alt="rating">
                                    </p>
                                    <p class="mb-3 review-label">Reviewed on 29 April 2024</p>
                                </div>

                            </div>
                        </div>
                        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                            printer
                            took a galley of type and scrambled it to make a type specimen book.</p>
                        <span>Verified User : Yes</span>
                    </div> -->
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script>
    document.getElementById('copyImage').addEventListener('click', function() {
        const url = `localhost:8000/user_profile/<?php echo e($data_user->id); ?>`;

        // Create a temporary input to hold the text
        const tempInput = document.createElement('input');
        tempInput.value = url;
        document.body.appendChild(tempInput);

        // Select the text and copy it
        tempInput.select();
        document.execCommand('copy');

        // Remove the temporary input
        document.body.removeChild(tempInput);

        // Show the notification
        const notification = document.getElementById('notification');
        notification.classList.remove('d-none');

        // Hide the notification after 2 seconds
        setTimeout(() => {
            notification.classList.add('d-none');
        }, 2000);
    });

    <?php if(session('message')): ?>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: '<?php echo e(session('message')); ?>',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });
    <?php endif; ?>

    $(document).ready(function() {
        //your clicks
        var table = $('.your-clicks').DataTable({
            "paging": true,
            "lengthChange": false,
            "info": false,
            "searching": false,
            "ordering": true,
            "pagingType": "full_numbers"
        });

        // $('#pagination').html($('.dataTables_paginate').html()); // Copy pagination controls from DataTables

        // // Handle custom pagination click events
        // $('#pagination').on('click', 'a', function(e) {
        //     e.preventDefault(); // Prevent default action
        //     var page = $(this).data('dt-page'); // Get page number from data attribute
        //     if (page) {
        //         table.page(page - 1).draw('page'); // Navigate to the specified page
        //     }
        // });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views/frontend/pages/userProfile.blade.php ENDPATH**/ ?>