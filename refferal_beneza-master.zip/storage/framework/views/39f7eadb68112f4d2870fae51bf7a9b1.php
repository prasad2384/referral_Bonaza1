<!DOCTYPE html>
<html lang="en">

    <head>
        <?php echo $__env->make('frontend.partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
       <style>
            <?php echo $__env->yieldContent('style'); ?>
        </style>
    </head>

    <body>
        <?php echo $__env->make('frontend.partial.navbar',['data' => $data ?? null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('frontend.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('frontend.partial.footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>

</html>
<?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views/frontend/layout.blade.php ENDPATH**/ ?>