<?php
use Illuminate\Support\Str;
?>

<?php $__env->startSection('title'); ?>
Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content mt-3">
    <div class="container-fluid">
        <!-- /.row -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title mt-1 fw-bold">Users Table</h3>
                        <div class="card-tools">
                            <a href="<?php echo e(url('admin/users/create')); ?>" class="btn btn-sm btn-primary fw-bold">Add User</a>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap" id="UserTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>UserName</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Logo</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>About</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone == '' ? '-' : $user->phone); ?></td>
                                    <td><?php echo $user->logo == '' ? '-' : "<img src='" . asset('images/' . $user->logo) . "' class='' style='width:50px'>"; ?></td>

                                    <td><?php echo e($user->address == '' ? '-' : Str::limit($user->address,5,'...')); ?></td>
                                    <td><?php echo e($user->status == 1 ? 'Active' : '-'); ?></td>
                                    <td><?php echo e($user->about == '' ? '-' : Str::limit($user->about,5,'...')); ?></td>
                                    <td class="d-flex">
                                        <form action="<?php echo e(url('admin/users/'.$user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="border rounded rounded-2 p-1 mx-2">
                                                <i class="fa-regular fa-trash-can fa-lg"></i>
                                            </button>
                                        </form>
                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="border rounded rounded-2 p-1 text-reset">
                                            <i class="fa-regular fa-pen-to-square fa-lg "></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td>No User Found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="px-4 mt-2">
                        <?php echo e($users->links()); ?>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
        <!-- /.row -->

        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    <?php if(session('message')): ?>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: '<?php echo e(session('message')); ?>',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });
    <?php endif; ?>
    // function DeleteUser(id) {
    //     $.ajax({
    //         url: '/admin/users/' + id,
    //         type: "Delete",
    //         data: {
    //             _token: '<?php echo e(csrf_token()); ?>'
    //         },
    //         success: function(response) {
    //             if (response.success) {
    //                 Swal.fire({
    //                     icon: 'success',
    //                     title: 'Success',
    //                     text: response.message,
    //                     toast: true,
    //                     position: 'top-end',
    //                     showConfirmButton: false,
    //                     timer: 4000,
    //                     timerProgressBar: true,
    //                     didOpen: (toast) => {
    //                         toast.addEventListener('mouseenter', Swal
    //                             .stopTimer)
    //                         toast.addEventListener('mouseleave', Swal
    //                             .resumeTimer)
    //                     }
    //                 });
    //                 $('#UserTable').find('tr').filter(function() {
    //                     return $(this).find('td').first().text() == id;
    //                 }).remove();

    //             } else {
    //                 alert(response.message);
    //             }
    //         }
    //     })
    // }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\admin\pages\Userlist.blade.php ENDPATH**/ ?>