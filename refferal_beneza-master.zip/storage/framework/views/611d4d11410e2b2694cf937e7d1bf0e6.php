<?php $__env->startSection('title', 'User Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php if(isset($error)): ?>
<div class=" pt-5 mt-5">
    <div class="alert alert-danger mt-5">
        <?php echo e($error); ?>

    </div>
</div>
<?php else: ?>
<!-- ======================= Main Profile START -->
<section class="position-relative overflow-hidden pb-0 pt-xl-9 profile-section">
    <div class="container pt-4 pt-sm-5">
        <div class="row pb-5  mb-5">
            <!-- Hero Image START -->
            <div class="col-sm-12 col-lg-3 profile-img">
                <!-- Hero image -->
                <?php if($data->logo == ''): ?>
                <img src="<?php echo e(asset('images/default_user_logo.png')); ?>" alt="profile-img">
                <?php else: ?>
                <img src="<?php echo e(asset('images/' . $data->logo)); ?>" alt="profile-img">
                <?php endif; ?>
            </div>
            <!-- Hero Image END -->
            <div class="col-sm-12 col-lg-9 profile-details">
                <div class="d-flex profile-info">
                    <div class="profile-data">
                        <h2><?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?></h2>
                        <h4 class="d-flex">
                            <span class="user-select-none">localhost:8000/user_profile/<?php echo e($data->id); ?> </span><img
                                src="<?php echo e(asset('images/img-9.png')); ?>" class="rounded" id="copyImage" alt="box-icon">
                            <span class="notification rounded-pill fs-6 p-2 d-none bg-black text-white"
                                id="notification"> copied!</span>
                        </h4>
                        
                    </div>
                    <div class="profile-btn">
                        <button class="msg-btn" data-bs-toggle="modal" data-bs-target="#messageModal"><img src="<?php echo e(asset('images/message-icon.png')); ?>" class="rounded"
                                alt="msg-icon">Message</button>
                    </div>
                </div>
                <p>
                    <!-- <?php echo e($average_rating); ?> -->
                    <?php for($i=0;$i< 5; $i++): ?>
                        <?php if($i < $average_rating): ?>
                        <span class="star">&#9733;</span>
                        <?php else: ?>
                        <span class="empty-star">&#9734;</span>
                        <?php endif; ?>
                        <?php endfor; ?>

                        <!-- <img src="<?php echo e(asset('images/img-10.png')); ?>" alt="rating" /><span><img
                                    src="<?php echo e(asset('images/img-11.png')); ?>" /></span> -->
                </p>
                <div class="profile-list">
                    <p class="pl-1">Member Since <?php echo e($data->created_at->format('Y')); ?> |
                        <span><?php echo e($referral_links_count); ?> </span>Referral Codes Created | <span><?php echo e($total_clicks); ?>

                        </span>Clicks Received
                    </p>
                    <p class="pl-2"><span>$500 </span>Bonus Shared | <span>$1500 </span>Bonus Shared In Last 1
                        Year
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- ======================= Main Profile END -->
<!-- ======================= Main Profile body START -->
<section class="position-relative overflow-hidden pb-0 pt-xl-9 referal-sec">
    <div class="container pt-4 pt-sm-5">
        <div class="row pb-5 px-3 mb-5">
            <h4 class="heading-underline mb-5 text-uppercase"> <?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?>’
                REFERRALS
            </h4>
            <div class="referral-table mb-5 table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">WEBSITE</th>
                            <th scope="col">OFFER AMOUNT</th>
                            <th scope="col">REFERRED ON</th>
                            <th scope="col">TRANSACTION RATING</th>
                            <th scope="col">TRANSACTION COMMENTS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $referral_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><img src="<?php echo e(asset('images/' . $referral_link->logo)); ?>" alt="name">
                            </td>
                            <td>$<?php echo e($referral_link->expected_payout_by_referar); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($referral_link->created_at)->format('d-m-Y')); ?></td>

                            <td>
                                <?php
                                $totalRating = 0;
                                $ratingCount = 0;
                                ?>
                                <?php $__currentLoopData = $all_ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($referral_link->id == $rating->referral_link_id): ?>
                                <?php
                                $totalRating += $rating->rating; // Assuming the rating column is 'rating'
                                $ratingCount++;
                                ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $averageRating = $ratingCount > 0 ? ceil($totalRating / $ratingCount) : 0;
                                $fullStars = $averageRating; // Number of full stars to display
                                $emptyStars = 5 - $fullStars; // Number of empty stars to display
                                ?>
                                <?php if($ratingCount > 0): ?>
                                <?php for($i = 0; $i < $fullStars; $i++): ?>
                                    <span class="star">&#9733;</span> <!-- Full Star -->
                                    <?php endfor; ?>

                                    <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                        <span class="empty-star">&#9734;</span> <!-- Empty Star -->
                                        <?php endfor; ?>
                                        <?php else: ?>
                                        <?php for($i=1;$i<=5;$i++): ?>
                                            <span class="empty-star">&#9734;</span>
                                            <?php endfor; ?>
                                            <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $displayedReferrerIds = [];
                                $messageDisplayed = false;
                                ?>

                                <?php $__currentLoopData = $user_review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($review->user_id == $data->id && $review->referral_link_id == $referral_link->id): ?>
                                <?php if(!in_array($review->referrer_id, $displayedReferrerIds)): ?>
                                <?php echo e($review->message); ?>

                                <?php
                                $displayedReferrerIds[] = $review->referrer_id;
                                $messageDisplayed = true;
                                ?>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if(!$messageDisplayed): ?>
                                Lorem ipsum dolor sit amet consectetur.
                                <?php endif; ?>
                                <!-- Lorem ipsum dolor sit amet consectetur. -->
                            </td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="12" class="text-center">Referral Link Not Found</td>
                        </tr>
                        <?php endif; ?>

                    </tbody>
                </table>

            </div>
            <div class="px-3 pt-3"><?php echo e($referral_links->links()); ?></div>
            
        </div>
    </div>

</section>

<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="messageModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex">
                <h5 class="modal-title" id="messageModalLabel">Send Message to <b><?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?></b></h5>
            </div>
            <div class="modal-body">
                <form id="messageForm">
                    <div class="form-group">
                        <!-- <label for="messageInput">type Message</label> -->
                        <textarea class="form-control" id="messageInput" rows="3" placeholder="Type your message here..." name="message"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="sendButton">Send</button>
            </div>
        </div>
    </div>
</div>


<!-- ======================= Main Profile body END -->
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    document.getElementById('copyImage').addEventListener('click', function() {

        <?php if(!empty($data)): ?>
        const url = `<?php echo e(url('user_profile/' . $data->id)); ?>`;

        // Create a temporary input to hold the text
        const tempInput = document.createElement('input');
        tempInput.value = url;
        document.body.appendChild(tempInput);

        // Select the text and copy it
        tempInput.select();
        document.execCommand('copy');

        // Remove the temporary input
        document.body.removeChild(tempInput);

        // Show the notification
        const notification = document.getElementById('notification');
        notification.classList.remove('d-none');

        // Hide the notification after 1 second
        setTimeout(() => {
            notification.classList.add('d-none');
        }, 1000);
        <?php endif; ?>

    });

    $(document).ready(function() {

        $('#messageModal').on('show.bs.modal', function() {
            $('#sendButton').prop('disabled', true);
        });

        $('#messageModal').on('hide.bs.modal', function() {
            $('#messageInput').val('');
            checkTextarea();
        });

        $('#messageInput').on('input', checkTextarea);

        $('#sendButton').click(function() {
            let message = $('#messageInput').val();
            if (message != '') {
                $.ajax({
                    url: "<?php echo e(url('save_message')); ?>",
                    type: 'POST',
                    data: {
                        'message': message,
                        'receiver_id': '<?php echo e($data->id); ?>'
                    },
                    headers: {
                        'X-CSRF-TOKEN': getCsrfToken() // Add the CSRF token to the request header
                    },
                    success: function(response) {
                        $('#messageModal').modal('hide')
                        $('#messageInput').val('');
                        Swal.fire({
                            icon: response.type,
                            title: response.type,
                            text: response.message,
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal
                                    .stopTimer)
                                toast.addEventListener('mouseleave', Swal
                                    .resumeTimer)
                            }
                        });
                    },
                    error: function(xhr) {
                        if (xhr.status === 401) { // Unauthenticated

                            alert('Please log in and send a message.');
                            window.location.href = "<?php echo e(route('login')); ?>"; // Redirect to login page
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Something went wrong. Please try again later.',
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            });
                        }
                    }
                });
            }
        });
    });

    function checkTextarea() { //hide show send message button
        var textarea = $('#messageInput');
        var button = $('#sendButton');

        button.prop('disabled', textarea.val().trim() === '');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\frontend\pages\user_profile_public.blade.php ENDPATH**/ ?>