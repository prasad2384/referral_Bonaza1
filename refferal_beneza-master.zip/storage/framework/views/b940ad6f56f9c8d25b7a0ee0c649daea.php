
<?php $__env->startSection('title', 'Referee Edit Profile'); ?>;
<?php $__env->startSection('style'); ?>
    .errors{
    font-weight:bold;
    color:red;
    }
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 ">
        <form id="submit_form" method="POST" action="<?php echo e(url('referee/update_profile/'.$data->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <div class="row p-5">
                <?php if($data->logo): ?>
                    <div class=" text-center mb-4">
                        <label class="fw-bold d-block">Profile Image</label>sdfgfd
                        <img src="<?php echo e(asset('images/' . $data->logo)); ?>" width="80px" alt="User Logo">
                    </div>
                <?php endif; ?>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">First Name</label>
                        <input type="text" name="firstname" value="<?php echo e($data->firstname); ?>" class="form-control" id="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">Last Name</label>
                        <input type="text" name="lastname" value="<?php echo e($data->lastname); ?>" class="form-control"
                            id="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">User Name</label>
                        <input type="text" name="username" value="<?php echo e($data->username); ?>" class="form-control"
                            id="">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-weight:bold; color:red"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">Email</label>
                        <input type="email" name="email" value="<?php echo e($data->email); ?>" class="form-control"
                            id="">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-weight:bold; color:red"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">Phone</label>
                        <input type="text" name="phone" value="<?php echo e($data->phone); ?>" class="form-control"
                            id="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">Upload Profile Image</label>
                        <input type="file" name="logo" class="form-control" id="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">About</label>
                        <textarea name="about" class="form-control" id="" cols="30" rows="3"><?php echo e($data->about); ?></textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="" class="fw-bold mb-2">Address</label>
                        <textarea name="address" class="form-control" id="" cols="30" rows="3"><?php echo e($data->address); ?></textarea>
                    </div>
                </div>

            </div>
            <button class="btn btn-primary float-end mb-5">
                Update Profile
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Ensure jQuery is loaded first -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- jquery-validation -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/additional-methods.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        if (typeof $.fn.validate !== 'undefined') {
            jQuery.validator.addMethod("noSpace", function(value, element) {
                return value.indexOf(" ") < 0 && value != "";
            }, "No space please and don't leave it empty");
            $.validator.addMethod("noDigits", function(value, element) {
                return this.optional(element) || !/\d/.test(value);
            }, "No digits allowed");
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[a-zA-Z\s]*$/.test(value);
            }, "No special characters allowed");
            $.validator.addMethod("alphanumeric", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9]+$/.test(value);
            }, "Only letters and numbers are allowed");
            $('#submit_form').validate({
                errorClass: 'errors',
                ignore: [],
                rules: {
                    firstname: {
                        required: true,
                        noSpace: true,
                        noDigits: true,
                        noSpecialChars: true,
                    },
                    lastname: {
                        required: true,
                        noSpace: true,
                        noSpecialChars: false,
                        noDigits: true,
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    phone: {
                        required: true,
                        minlength: 10,
                    },
                    username: {
                        required: true,
                        minlength: 5,
                        maxlength: 32,
                        alphanumeric: true,
                    },
                    logo: {
                        required: false,
                        accept: "image/*"
                    },
                    about: {
                        required: true,
                    },
                    address: {
                        required: true,
                    }
                },
                messages: {
                    firstname: {
                        required: "Please enter your first name",
                    },
                    lastname: {
                        required: "Please enter your last name",
                    },
                    email: {
                        required: "Please enter your email",
                        email: "Invalid email address"
                    },
                    phone: {
                        required: "Please enter your phone number",
                        minlength: "Please Enter valid phone number"
                    },
                    username: {
                        required: "Please enter your username",
                        minlength: "Username must be at least 5 characters long",
                        maxlength: "Username must be no more than 32 characters long",
                        alphanumeric: "Username can only contain letters and numbers",
                    },

                    logo: {
                        required: "Please upload file.",
                        accept: "Please upload file in these format only (jpg, jpeg, png, ico, bmp)."
                    },
                    about: {
                        required: "Please enter your description"
                    },
                    address: {
                        required: "Please enter your address"
                    }
                },
                submitHandler: function(form, event) {
                    form.submit();
                    // $('#error_email').text('');
                    // $('#error_username').text('');
                    // event.preventDefault();
                    // var formData = new FormData(form);
                    // var id = $(form).data('id');
                    // $.ajax({
                    //     type: "Post",
                    //     url: '/referee/update_profile/' + id,
                    //     data: formData,
                    //     contentType: false,
                    //     processData: false,
                    //     success: function(response) {
                    //         console.log(response);
                    //         if (response.errors) {
                    //             if (response.errors && response.errors.email && response.errors
                    //                 .email[
                    //                     0]) {
                    //                 $('#error_email').text(response.errors.email[0]);
                    //             }
                    //             if (response.errors && response.errors.username && response.errors
                    //                 .username[0]) {
                    //                 $('#error_username').text(response.errors.username[0]);
                    //             }
                    //         } else {
                    //             form.reset();
                    //             Swal.fire({
                    //                 icon: 'success',
                    //                 title: 'Success',
                    //                 text: response.message,
                    //                 toast: true,
                    //                 position: 'top-end',
                    //                 showConfirmButton: false,
                    //                 timer: 4000,
                    //                 timerProgressBar: true,
                    //                 didOpen: (toast) => {
                    //                     toast.addEventListener('mouseenter', Swal
                    //                         .stopTimer)
                    //                     toast.addEventListener('mouseleave', Swal
                    //                         .resumeTimer)
                    //                 }
                    //             });
                    //             setInterval(() => {
                    //                 window.location.href = '/referee/referee_dashboard';
                    //             }, 4000);
                    //         }
                    //     },
                    //     error: function(error) {
                    //         console.log(error);
                    //     }
                    // })
                }
            });
        } else {
            console.error('jQuery validation plugin is not loaded');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\frontend\Refereepages\edit_profile.blade.php ENDPATH**/ ?>