<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content mt-3">
        <div class="container-fluid">
            <!-- /.row -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title mt-1 fw-bold">Category Table</h3>
                            <div class="card-tools">
                                <a href="<?php echo e(url('admin/category/create')); ?>" class="btn btn-sm btn-primary fw-bold">Add Category</a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap" id="CategoryTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td class="d-flex align-items-center ">
                                                <form action="<?php echo e(url('admin/category/'. $category->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="border rounded rounded-2 p-1 mx-2">
                                                        <i class="fa-regular fa-trash-can fa-lg"></i>
                                                    </button>
                                                </form>
                                                <!-- <button class="btn btn-danger btn-sm mx-2"
                                                    onclick="DeleteCategory(<?php echo e($category->id); ?>)">D</button> -->
                                                <a href="<?php echo e(route('category.edit', $category->id)); ?>" class='p-1 rounded rounded-2 border text-reset'>
                                                    <i class="fa-regular fa-pen-to-square fa-lg"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td>No Category Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                          <div class="px-4">
                        <?php echo e($data->links()); ?>

                    </div>
                    </div>
                  
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.row -->

            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('message')): ?>
            Swal.fire({
                icon: '<?php echo e(session('alert-type', 'success')); ?>',
                title: '<?php echo e(session('alert-type') == 'success' ? 'Success' : 'Warning'); ?>',
                text: '<?php echo e(session('message')); ?>',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            }); 
         <?php endif; ?>
        function DeleteCategory(id) {
            $.ajax({
                url: '/admin/category/' + id,
                type: "Delete",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal
                                    .stopTimer)
                                toast.addEventListener('mouseleave', Swal
                                    .resumeTimer)
                            }
                        });
                        $('#CategoryTable').find('tr').filter(function() {
                            return $(this).find('td').first().text() == id;
                        }).remove();

                    } else {
                         Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: response.message,
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal
                                    .stopTimer)
                                toast.addEventListener('mouseleave', Swal
                                    .resumeTimer)
                            }
                        });
                    }
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\admin\pages\CategoryList.blade.php ENDPATH**/ ?>