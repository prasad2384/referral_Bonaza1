
<?php $__env->startSection('title','All Websites'); ?>
<?php $__env->startSection('content'); ?>
<section class="pt-5 pb-5 banking-section mt-5 pt-5">
    <div class="container pb-5 mt-5">
        <div class="d-flex pb-4 banking-header">
            <h3 class="text-center"><?php echo e($category->name); ?></h3>
        </div>
        <div class="row row-cols-2 row-cols-sm-3 row-cols-lg-6 g-4">
            <?php $__currentLoopData = $referral_website; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('website_details/' . $website_data->id)); ?>" class="col text-decoration-none">
                <div class="rounded p-4 banking-box">
                    <img src="<?php echo e(asset('images/' . $website_data->logo)); ?>" alt="<?php echo e($website_data->canonicalized_name); ?>" />
                    <h5 class="pt-3"><?php echo e($website_data->canonicalized_name); ?></h5>
                    <h6>$<?php echo e($website_data->expected_payout); ?></h6>
                </div>
            </a>
            <!-- Item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\frontend\pages\all_websites.blade.php ENDPATH**/ ?>