<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($emailMessage); ?></p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\refferal_beneza-master\resources\views\emails\mail.blade.php ENDPATH**/ ?>